
// Comando simulado de entrega automática (substitua por lógica real se necessário)
