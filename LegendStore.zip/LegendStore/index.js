
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const config = require('./config.json');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ]
});

client.commands = new Collection();

// Carregar eventos
const eventos = fs.readdirSync('./eventos').filter(file => file.endsWith('.js'));
for (const file of eventos) {
  require(`./eventos/${file}`)(client);
}

client.login(config.token);
