
module.exports = (client) => {
  console.log(`Bot ${client.user.tag} está online!`);
};
