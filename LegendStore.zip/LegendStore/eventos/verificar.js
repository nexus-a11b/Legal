
const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.json');

module.exports = (client) => {
  client.on(Events.ClientReady, async () => {
    const canal = await client.channels.fetch(config.id_verificacao);
    if (!canal) return;

    const embed = new EmbedBuilder()
      .setTitle('Verificação')
      .setDescription('Clique no botão abaixo para se verificar e acessar os canais.')
      .setColor('Green');

    const botao = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('verificar')
        .setLabel('Verificar')
        .setStyle(ButtonStyle.Success)
    );

    await canal.send({ embeds: [embed], components: [botao] });
  });

  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'verificar') {
      const cargo = interaction.guild.roles.cache.get(config.cargo_cliente);
      if (!cargo) return interaction.reply({ content: 'Cargo não encontrado.', ephemeral: true });

      await interaction.member.roles.add(cargo);
      await interaction.reply({ content: 'Você foi verificado com sucesso!', ephemeral: true });

      const canalLogs = interaction.guild.channels.cache.get(config.id_logs_verificacao);
      if (canalLogs) {
        canalLogs.send(`${interaction.user.tag} foi verificado.`);
      }
    }
  });
};
